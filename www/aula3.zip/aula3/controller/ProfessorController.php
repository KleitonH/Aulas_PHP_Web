<?php

class ProfessorController {
    public function listar() {
        echo "Lista de professores";
    }
}